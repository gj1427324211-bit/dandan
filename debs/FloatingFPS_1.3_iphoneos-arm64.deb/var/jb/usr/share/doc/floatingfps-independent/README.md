# 悬浮FPS 1.3

名称：悬浮FPS；作者/维护者：蛋蛋；包ID：net.floatingfps.independent。仅独立FPS插件，未修改Widget。保留显示开关、X/Y百分比、字号、跟随状态栏开关、用户ZIP原有图标；没有样式列表、拖动、描边或阴影。

## 针对旋转黑块的修改

用户截图中照片内录制的38 FPS周围可见十字黑条；照片应用顶部另有实时0 FPS，不能混为同一浮窗。截图说明此前方案未能解决问题，但不能据此断言具体UIKit生成栈。

1. 移除1.2每次按标签尺寸修改UIWindow.frame、root.view.frame的路径。现在窗口仅创建时设为scene.coordinateSpace.bounds全场景尺寸，之后窗口/根视图尺寸和方向由UIKit管理，绝不把窗口裁成标签大小、不写transform。
2. 标签仅在hudRoot.view.bounds内按X/Y可移动距离百分比定位，禁用隐式动作并按屏幕像素对齐。窗口/根视图/文字均clear、opaque=NO、layer.opaque=NO，contentScaleFactor使用同一scene.screen.scale。
3. 修复1.2控制器吞掉基类旋转/布局方法的缺陷：运行时注册子类前保存UIViewController基类IMP，以准确id/SEL/CGSize/coordinator签名调用，再执行自身布局/完成回调。没有全局旋转hook。
4. 转场期间临时隐藏标签，窗口仍存活并正常参与UIKit旋转；完成或取消后按实际root.bounds重新布局恢复。取舍是旋转时FPS短暂不可见，避免把文字转场快照带入最终画面；这不是实机已验证无黑条的承诺。
5. 全场景窗口仍userInteractionEnabled=NO，从不makeKeyWindow。自身运行时UIWindow子类在设备确实存在且返回BOOL签名正确时，仅覆盖_canAffectStatusBarAppearance返回NO，避免高层窗口成为系统状态栏策略来源；未硬编码状态栏风格，未hook其他窗口。声明证据为https://github.com/nst/iOS-Runtime-Headers/blob/master/PrivateFrameworks/UIKitCore.framework/UIWindow.h 。私有选择器缺失时退回默认实现，不能保证该系统版本的状态栏策略隔离。
6. 同一scene/window跨临时inactive保留；后台/锁屏隐藏，断连或关闭销毁。既有通知和timer只作布局兜底，不轮询写窗口frame。颜色中继1.2源码及协议完全不变，HUD根视图只含UILabel，没有_UIStatusBar，不产生中继自有颜色来源。

仅完成源码修正、真实编译链接签名和静态回归，不宣称设备旋转黑条已实测消失。

## 实际状态栏颜色

- 观察_UIStatusBar setForegroundColor:，原IMP先运行，检查getter/ setter签名后按准确ABI调用；没有PAC stripping、整数函数指针、ivar/KVC或全局objc_msgSend hook。
- 读取真实foregroundColor，以来源view.traitCollection resolve动态UIColor后取RGB或灰度。有效alpha>0.05，有限分量按前景亮度0.5分黑白，不再用0.25/0.75把中灰丢弃；不按背景计算对比度。半透明只作有效性检查，不猜背景混合。
- 找不到缓存实际bar时，优先接受来源scene的UIStatusBarManager明确LightContent=白、DarkContent=黑。Default不按主题推断。
- 弱缓存实际bar，setter立即更新并合并一次异步恢复；激活时强制报告。只有前台active主屏可见来源可发布。恢复扫描每scene最多384节点、深度16，正常有缓存bar或明确manager时不遍历。
- 分离应用和SpringBoard两个notify状态流，打包颜色、22位PID、40位uptime毫秒。新鲜应用报告优先，SpringBoard不能用自己的流覆盖它；2秒前台心跳续租，5秒超时失效。应用inactive时停timer并在共享状态PID仍为自己时释放，接收端复用FPS timer处理租约超时，无新增接收timer。未知保持最后可靠颜色；关闭跟随固定白。
- 仍是UIApplication类过滤的广应用注入，构造器只接受.app；不绕过用户禁用注入。HUD只在SpringBoard创建，应用只报告颜色。

## 优化及生命周期审计

取消0.5秒无条件全量HUD布局/颜色应用；字体仅字号变化时更新，frame仅几何变化时写入。中继从每秒扫描改为2秒active-only续租/缺源恢复，后台timer invalidate并置nil。ARC全局window/controller/timer/observer token是进程级持有；observer块不捕获自身token或timer，不存在自引用保活环。弱bar不会持有应用视图。notify注册/CF observer/采样timer各安装一次，进程退出由系统回收；没有支持dylib卸载的API，未虚构卸载清理。保留QuartzCore dlopen handle保证函数指针有效。

独立重写，原FPSHUD创意归Axs，无原二进制/代码复制。FPS仍为CARenderServerGetDirtyFrameCount(0)聚合脏帧估计，不是前台应用呈现FPS；符号缺失N/A，约1秒采样、1.5秒EMA、限制屏幕最高帧率，暂停重建基线。

## 构建与未验证限制

LLVM21.1.2、Apple ld64-956.6；arm64e-apple-ios16.0，ARC/blocks，-Os -Wall -Wextra -Werror，SDKSettings报告16.4（目录名iPhoneOS16.5.sdk），chained fixups，ldid -S本地伪签名（实际CodeDirectory flags=0，未声称CS_ADHOC位为真）。三个组件重新编译。QuartzCore导出stub从SDK生成只用于严格链接，不装进deb；不使用undefined dynamic_lookup。

PID不是经过验证的真实前台owner。分流/租约阻止SpringBoard直接覆盖新鲜应用报告，但不能彻底解决两应用短暂同时active、多scene、notify合并或旧应用释放时get/set非原子竞态。未读取私有前台bundle getter，不伪造owner。程序被杀未释放最多等5秒；用户禁用中继、沙箱notify权限、远程状态栏托管路径可能导致缺报告。隐藏状态栏时没有承诺立即清除颜色。来源UIColor的语义resolve不是像素取样。

构建、Mach-O、代码目录hash及包资源审计不能证明设备PAC执行/信任通过。尚未实机验证旋转黑块、锁屏恢复和跨应用颜色；不宣称运行成功。建议验收横竖屏反复切换、旋转后位置、同主题黑/白实际系统时间字色页面、应用切换、锁屏、跟随关闭和触摸穿透。

交付FloatingFPS_1.3_iphoneos-arm64.deb；保留1.2原包及rollback-1.2源码。没有自动安装、重启或提供安装命令。

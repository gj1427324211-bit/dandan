# 悬浮FPS 1.1

作者/维护者：蛋蛋。用户确认1.0的悬浮显示可用，但状态栏跟随不可用。本版保留FPS、位置、字号、触摸穿透及窗口生命周期，重做颜色组件。已编译并静态审计，尚未实机验证新增跨应用路径。

## 实际状态栏颜色中继

- FloatingFPSIndependent.dylib仍只注入com.apple.springboard，只有该组件创建HUD。
- 新增FloatingFPSColorRelay.dylib，Filter.Classes=[UIApplication]。这是覆盖UIKit应用的较广注入范围，不是仅SpringBoard扫描；普通无UIApplication类的后台守护进程不匹配。构造器还要求主bundle为.app。应用禁用tweak注入时无法覆盖，不绕过禁用策略。中继在应用中不创建窗口、不采样FPS、不改偏好。
- ElleKit公开源码evelyneee/ellekit main的injector/injector.c明确解析Filter/Classes并通过objc_getClass匹配。源码快照：research/ellekit-injector.c。Substrate过滤格式文档：https://www.cydiasubstrate.com/inject/darwin/ ，快照research/substrate-filter.html。
- 唯一方法观察：_UIStatusBar setForegroundColor:。iOS16运行时头research/iOS16-_UIStatusBar.h明确声明getter和setter。安装前验证void返回、三个参数、对象参数；用真正objc/runtime的IMP保存原方法，调用void(id,SEL,id)准确ABI。继承方法以class_addMethod覆盖到具体_UIStatusBar类，绝不修改UIView或UIApplication方法。已有方法用method_setImplementation，原实现先执行，再读取getter。无手写跳板、PAC stripping、指针转整数、任意ivar/KVC、objc_msgSend全局hook。观察异常被捕获，原方法的原本异常语义不被改写。
- 发布必须本应用UIApplicationStateActive，来源为主屏可见附着窗口、前台active scene、非空状态栏，祖先不可隐藏或透明。只接受alpha>=0.85、RGB极差<=0.10、亮度<=0.25的黑或>=0.75的白；不推断灰色/彩色。getter签名校验后准确调用。
- Setter事件立即读取并异步再查一次，以覆盖更新后的附着。激活事件强制重报；每秒低频恢复检查只在active应用扫描有界视图树，处理setter发生在附着前等情况。无频繁磁盘读写。明确的UIStatusBarManager LightContent只映射白、DarkContent只映射黑；Default不推断，不按trait主题取色。manager只能代表本应用scene，不是像素取样。
- 使用SDK notify.h公开C API notify_register_check、notify_set_state、notify_post传递1=黑/2=白。SpringBoard通过notify_register_dispatch主队列即时更新，notify_get_state获取状态。没有修改通知系统权限或安全策略。
- 找不到可靠来源时保留最后可靠报告；从未收到则保守白色。关闭跟随固定白色。无trait深浅回退、无背景色猜测、无描边或阴影。

## 必须说明的限制

这是全局共享通知状态，接收端不验证当前前台owner/PID。仅来源active且可见的检查能排除普通后台报告，不能排除SpringBoard和另一应用同时active、多scene、转场或通知合并导致最后报告者不等于最终显示者；没有伪造前台PID。每次应用激活强制重报，但未收到的空窗仍保留旧色。安全沙箱/notify权限、实际_UIStatusBar远程托管路径、特定越狱加载器版本的类过滤时机和arm64e设备PAC执行仍需要真实设备验证。没有宣称所有应用100%同步或已验证运行成功。

## FPS与原有行为

独立重写，原始FPSHUD创意归Axs，本版本不表示Axs认可且未复制原版二进制。FPS使用私有CARenderServerGetDirtyFrameCount(0)渲染服务器脏帧聚合计数，不是前台应用真实呈现FPS；符号缺失显示N/A。约每秒按真实uptime差采样、1.5秒EMA平滑并限于屏幕最高帧率，暂停/回退/长间隔重建基线。HUD自身更新会影响聚合值。保留0.5秒布局和foreground-active主屏scene策略，不改变用户已验证的FPS功能。若原有策略无scene时隐藏，仍隐藏。

## 构建与安装

目标arm64e-apple-ios16.0，rootless安装/var/jb，包ID net.floatingfps.independent，版本1.1，名称悬浮FPS，作者蛋蛋。LLVM21 + Apple ld64-956.6，真实iOS16.5 SDK目录（SDKSettings版本16.4），-Wall -Wextra -Werror、ARC、blocks，chained fixups，ldid本地ad-hoc签名。三个dylib均新编译；链接SDK导出stub不安装到包中。不使用-undefined dynamic_lookup或旧tweak二进制。静态签名和构建成功不能证明设备信任或PAC运行成功。

产物FloatingFPS_1.1_iphoneos-arm64.deb。安装后应重新载入SpringBoard并完全退出后重开测试应用，使中继载入；不自动安装或重启。不同应用若在越狱设置禁用了注入，中继不运行。保留旧设置。先禁用其他FPS插件，避免双HUD。

验收：同一系统主题下，打开实际系统时间/电池字色分别为黑/白的两种页面，切换页面和应用，确认HUD跟随实际字色而不是主题；再验证启动恢复、横竖屏、锁屏解锁、隐藏状态栏、关闭跟随固定白色以及触摸穿透。如果失败，应提供具体应用/页面、系统时间与HUD实际字色；此版未实机验收。

图标重新来自用户ZIP 20261014025526896TempImage.zip中的PNG，忽略__MACOSX，Pillow重采样29/58/87像素设置图标及包图标。设置仅显示开关、X/Y、字号、跟随开关。资源0644、目录与dylib0755，deb root:root。
